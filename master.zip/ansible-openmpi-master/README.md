ansible-openmpi
===============
